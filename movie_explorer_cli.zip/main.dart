import 'dart:convert';
import 'package:http/http.dart' as http;

void main() async {
  const String accessToken =
      'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzNWZkMzQxMmRlMDU4Mzk5M2RmZWEwMmMxNjljMTQ3MiIsIm5ZiI6MTc0MjU1MjAxNC45NDIwMDAyLCJzdWIiOiI2N2RkM2JjZWM3MGFjZGQ5ZGY2OTgzZWUiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.bY7rGoQ1R07wM2W0pvWrgkdG7bQ2sT5UD6NRp8joz_4';

  final url = Uri.parse('https://api.themoviedb.org/3/trending/movie/week');

  try {
    final response = await http.get(
      url,
      headers: {
        'Authorization': 'Bearer $accessToken',
        'accept': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final movies = data['results'];
      print('🎬 Trending Movies:\n');
      for (var movie in movies) {
        print('• \${movie['title']}');
      }
    } else {
      print('⚠️ TMDB API failed! Status: \${response.statusCode}');
      fallbackMovies();
    }
  } catch (e) {
    print('❌ Error calling TMDB API: \$e');
    fallbackMovies();
  }
}

void fallbackMovies() {
  List<String> dummyMovies = [
    'Inception',
    'The Dark Knight',
    'Interstellar',
    'Parasite',
    'Avengers: Endgame',
  ];
  print('\n📄 Fallback Movie List:');
  for (var title in dummyMovies) {
    print('• \$title');
  }
}
